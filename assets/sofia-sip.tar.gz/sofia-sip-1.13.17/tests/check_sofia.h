#ifndef CHECK_SOFIA_H

#include <check.h>
Suite *suite_for_nua(void);

#endif

